﻿namespace Metabase.Controllers
{

    public record NumberOfRowsAffectedResponseDTO
    {
        public int NumberOfRowsAffected { get; set; }
    }

}
