﻿namespace Metabase.Models.Constraints
{
    public abstract class ConstraintModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
